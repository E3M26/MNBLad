@echo off
REM MNBLad Panel - internetsiz calisir. Kurulum gerekmez.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0sunucu.ps1"
