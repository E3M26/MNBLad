# MNBLad Panel - internetsiz yerel sunucu (kurulum gerektirmez: Windows PowerShell 5.1 + .NET HttpListener)
# Paneli http://localhost:<port>/ adresinde sunar ve Edge/Chrome'u uygulama penceresi olarak acar.
# Web Serial (USB ile karta baglanma) yalniz https veya localhost adresinde calisir; bu yuzden sunucu gerekir.
# Pencereyi kapatinca sunucu durur.
param([int]$Port = 8765, [switch]$TarayiciAcma)
$ErrorActionPreference = 'Stop'
$root = Join-Path $PSScriptRoot 'web'
$Host.UI.RawUI.WindowTitle = 'MNBLad Panel sunucusu'

# Bos port bul (8765, 8766, ...)
$listener = $null
foreach ($p in $Port..($Port + 30)) {
  try {
    $l = New-Object System.Net.HttpListener
    $l.Prefixes.Add("http://localhost:$p/")
    $l.Start()
    $listener = $l; $Port = $p; break
  } catch { }
}
if (-not $listener) { Write-Host 'Bos port bulunamadi.' -ForegroundColor Red; Read-Host 'Kapatmak icin Enter'; exit 1 }

$url = "http://localhost:$Port/"
$mime = @{
  '.html' = 'text/html; charset=utf-8'; '.js' = 'text/javascript; charset=utf-8'; '.mjs' = 'text/javascript; charset=utf-8'
  '.json' = 'application/json; charset=utf-8'; '.css' = 'text/css; charset=utf-8'; '.png' = 'image/png'; '.svg' = 'image/svg+xml'
  '.bin' = 'application/octet-stream'; '.txt' = 'text/plain; charset=utf-8'; '.ico' = 'image/x-icon'
}

Write-Host ''
Write-Host '  MNBLad Panel' -ForegroundColor DarkYellow
Write-Host "  Adres: $url"
Write-Host '  Bu pencere acik kaldikca panel calisir. Kapatinca sunucu durur.'
Write-Host ''

# Tarayici: Edge (uygulama penceresi), yoksa Chrome, yoksa varsayilan tarayici
$edge = @("${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe", "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
$chrome = @("$env:ProgramFiles\Google\Chrome\Application\chrome.exe", "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe", "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
if ($TarayiciAcma) { }
elseif ($edge) { Start-Process $edge "--app=$url" }
elseif ($chrome) { Start-Process $chrome "--app=$url" }
else { Start-Process $url; Write-Host '  Uyari: USB baglantisi icin Chrome veya Edge gerekir.' -ForegroundColor Yellow }

$rootFull = [System.IO.Path]::GetFullPath($root)
while ($listener.IsListening) {
  try { $ctx = $listener.GetContext() } catch { break }
  $res = $ctx.Response
  try {
    $rel = [Uri]::UnescapeDataString($ctx.Request.Url.AbsolutePath.TrimStart('/'))
    if ($rel -eq '') { $rel = 'index.html' }
    $file = [System.IO.Path]::GetFullPath((Join-Path $rootFull $rel))
    if ((Test-Path $file -PathType Container)) { $file = Join-Path $file 'index.html' }
    if (-not $file.StartsWith($rootFull, [StringComparison]::OrdinalIgnoreCase) -or -not (Test-Path $file -PathType Leaf)) {
      $res.StatusCode = 404
      $b = [Text.Encoding]::UTF8.GetBytes('Bulunamadi')
      $res.OutputStream.Write($b, 0, $b.Length)
    } else {
      $ext = [System.IO.Path]::GetExtension($file).ToLower()
      $res.ContentType = if ($mime.ContainsKey($ext)) { $mime[$ext] } else { 'application/octet-stream' }
      $res.Headers.Add('Cache-Control', 'no-cache')
      $bytes = [System.IO.File]::ReadAllBytes($file)
      $res.ContentLength64 = $bytes.Length
      $res.OutputStream.Write($bytes, 0, $bytes.Length)
    }
  } catch { try { $res.StatusCode = 500 } catch { } }
  finally { try { $res.OutputStream.Close() } catch { } }
}
